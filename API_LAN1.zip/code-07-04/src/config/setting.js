module.exports = {
    secretJWT: 'abcdefgh',
    otpExipred: 300
}