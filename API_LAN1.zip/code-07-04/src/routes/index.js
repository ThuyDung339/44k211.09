import { Router } from 'express';
import auth from './auth';
import user from './user';

let routerApp = new Router();

routerApp.use('/auth', auth);
routerApp.use('/user', user);

export default routerApp;