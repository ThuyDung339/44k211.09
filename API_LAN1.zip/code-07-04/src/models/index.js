export { default as Users } from './User';

import { sequelize } from '../connections';

// for (let m in sequelize.models) {
//     sequelize.models[m].sync();
// }

for (let m in sequelize.models) {
    sequelize.models[m].association();
}